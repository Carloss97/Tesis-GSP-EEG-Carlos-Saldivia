# QA Report: it111_iris_graph_lambda_grid

## Status: NO-GO

## Summary
- Total rows: 160
- Methods tested: 4
- Graphs: 1
- Missing scenarios: 1
- Best method: trss (MAE=9.0477e-02)

## Statistical Test (Mann-Whitney U: TV < Instant)
- TV median MAE:      nan
- Instant median MAE: nan
- Gain:               0.0%
- p-value:            1.0000e+00
- Decision:           **NO-GO**

## Dataset availability snapshot
- bci_iv2a_real_s1: OK
- bci_iv2a_real_s2: OK
- bci_iv2a_real_s3: OK
- iris_graph_signal: OK
- iv100hz_mat: OK
- movielens_graph_signal: OK
- physionet_real: OK

Generated: 2026-04-06T19:16:39.285077+00:00