# QA Report: rerun_189_movielens_graph_signal_knn__k5_tv

## Status: NO-GO

## Summary
- Total rows: 6
- Methods tested: 1
- Graphs: 1
- Missing scenarios: 1
- Best method: tv (MAE=3.9673e-02)

## Statistical Test (Mann-Whitney U: TV < Instant)
- TV median MAE:      nan
- Instant median MAE: nan
- Gain:               0.0%
- p-value:            1.0000e+00
- Decision:           **NO-GO**

## Dataset availability snapshot
- bci_iv2a_real_s1: OK
- bci_iv2a_real_s2: OK
- bci_iv2a_real_s3: OK
- iris_graph_signal: OK
- iv100hz_mat: OK
- movielens_graph_signal: OK
- physionet_real: OK

Generated: 2026-04-14T19:57:05.457598+00:00