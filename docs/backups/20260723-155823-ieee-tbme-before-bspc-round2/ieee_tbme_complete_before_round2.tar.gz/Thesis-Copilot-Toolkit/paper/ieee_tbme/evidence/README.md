# Evidence manifest for the BSPC review draft

This directory identifies the frozen artifacts used to support the quantitative statements in `paper/ieee_tbme`. It is a provenance manifest, not a claim that the ignored `results/` tree is already a public replication package.

Protocol boundary:

- 300 exactly paired TRSS--MNE cases.
- 100 dataset--missingness clusters, each containing seeds 0, 1, and 2.
- Fixed TRSS configuration only; tuned/oracle rows are not manuscript evidence.
- Two synthetic controls, two EEGMMIDB records, and one MNE Sample segment.
- Descriptive paired effects and cluster-bootstrap intervals; no hypothesis-test claim.

Roles of the listed artifacts:

- `derived_balanced.csv`: frozen row-level paired benchmark source.
- `robust_pairwise_summary.csv`: overall metric summaries.
- `robust_by_dataset.csv`: stratum-specific summaries.
- `robust_by_missing_scenario.csv`: missingness-condition summaries.
- `metadata.json`: robust-analysis configuration and run metadata.
- `trss_vs_mne_bads_extensive.py`: benchmark generator.
- `analyze_trss_mne_robust_stats.py`: robust summary generator.
- `src/`: loader, geometry graph, and reconstruction implementation.
- `prepare_figures.py` and the three listed PDFs: editorial transformations of the frozen summaries.

Verification from the `Thesis-Copilot-Toolkit` directory:

```sh
sha256sum -c paper/ieee_tbme/evidence/SHA256SUMS.txt
```

The source datasets remain governed by their original distribution terms. The manifest records exact local provenance but does not create a new license for those source recordings.
