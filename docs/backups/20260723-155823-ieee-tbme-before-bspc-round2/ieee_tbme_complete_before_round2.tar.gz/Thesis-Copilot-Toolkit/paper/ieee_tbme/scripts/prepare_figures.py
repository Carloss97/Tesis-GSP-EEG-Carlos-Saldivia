"""Create publication figures from the frozen thesis result tables.

This script does not rerun reconstruction experiments. It only translates and
restyles values already reported in the thesis result CSV files.
"""
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RESULTS = ROOT / "results" / "trss_vs_mne_bads_extensive" / "robust_stats"
OUT = HERE.parent / "figures"

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.size": 9,
        "axes.labelsize": 9,
        "axes.titlesize": 9,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "pdf.fonttype": 42,
    }
)
BLUE = "#0072B2"
ORANGE = "#D55E00"
GREEN = "#009E73"
GRAY = "#4D4D4D"


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def save(fig: plt.Figure, name: str) -> None:
    fig.savefig(OUT / name, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def metric_portfolio() -> None:
    source = rows(RESULTS / "robust_pairwise_summary.csv")
    selected = {
        row["metric"]: row
        for row in source
        if row["comparison"] == "trss_default vs MNE"
    }
    metrics = ["mae", "rmse", "nrmse", "dtw", "snr", "lsd", "coherence_mean", "corr_mean"]
    labels = ["MAE", "RMSE", "NRMSE", "DTW", "SNR", "LSD", "Coherence", "Correlation"]
    improvements = [100 * float(selected[m]["median_improvement"]) for m in metrics]
    ci_low = [100 * float(selected[m]["boot_median_improvement_ci_low"]) for m in metrics]
    ci_high = [100 * float(selected[m]["boot_median_improvement_ci_high"]) for m in metrics]
    colors = [BLUE if x >= 0 else ORANGE for x in improvements]
    fig, ax = plt.subplots(figsize=(7.05, 3.15))
    y = np.arange(len(metrics))
    ax.axvline(0, color=GRAY, linewidth=0.7, zorder=0)
    for position, value, lower, upper, color in zip(y, improvements, ci_low, ci_high, colors):
        ax.errorbar(
            value,
            position,
            xerr=[[value - lower], [upper - value]],
            fmt="o",
            color=color,
            ecolor=color,
            elinewidth=1.2,
            capsize=3,
            markersize=5,
            zorder=3,
        )
    ax.set_xlim(min(ci_low) - 3, max(ci_high) + 5)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("Median relative improvement over MNE spherical splines (%)")
    ax.grid(axis="x", color="#D0D0D0", linewidth=0.5)
    ax.spines[["top", "right", "left"]].set_visible(False)
    save(fig, "metric_portfolio.pdf")


def dataset_summary() -> None:
    source = rows(RESULTS / "robust_by_dataset.csv")
    selected = [r for r in source if r["method"] == "trss_default" and r["metric"] == "mae"]
    order = ["synthetic_smooth", "synthetic_rough", "physionet_s1_r4_w0", "physionet_s2_r4_w0", "mne_sample_w0"]
    names = ["Synthetic smooth", "Synthetic rough", "PhysioNet subject 1", "PhysioNet subject 2", "MNE Sample"]
    lookup = {r["dataset"]: r for r in selected}
    imp = [100 * float(lookup[d]["median_improvement"]) for d in order]
    win = [100 * float(lookup[d]["win_rate"]) for d in order]
    y = np.arange(len(order))
    fig, axes = plt.subplots(1, 2, figsize=(7.05, 3.10), sharey=True, gridspec_kw={"wspace": 0.08})
    accuracy_bars = axes[0].barh(y, imp, color=[BLUE if v >= 0 else ORANGE for v in imp], height=0.64)
    axes[0].axvline(0, color="black", linewidth=0.7)
    axes[0].set_xlim(-20, 30)
    axes[0].set_xlabel("Median MAE improvement (%)")
    win_bars = axes[1].barh(y, win, color=GREEN, height=0.64)
    axes[1].axvline(50, color=GRAY, linestyle="--", linewidth=0.8)
    axes[1].set_xlim(0, 115)
    axes[1].set_xlabel("TRSS MAE win rate (%)")
    axes[0].set_yticks(y, names)
    axes[0].invert_yaxis()
    axes[1].tick_params(axis="y", labelleft=False)
    axes[0].bar_label(accuracy_bars, fmt="%.1f", padding=3, fontsize=8)
    axes[1].bar_label(win_bars, fmt="%.1f", padding=3, fontsize=8)
    for ax in axes:
        ax.grid(axis="x", color="#D0D0D0", linewidth=0.5)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_title("(a) Relative accuracy")
    axes[1].set_title("(b) Pairwise wins")
    save(fig, "dataset_summary.pdf")


def runtime_tradeoff() -> None:
    source = rows(RESULTS / "robust_pairwise_summary.csv")
    selected = {
        row["metric"]: row
        for row in source
        if row["comparison"] == "trss_default vs MNE"
    }
    mae = selected["mae"]
    run = selected["runtime_s"]
    labels = ["MNE spline", "TRSS"]
    times = [float(run["b_median"]), float(run["a_median"])]
    errors = [1e6 * float(mae["b_median"]), 1e6 * float(mae["a_median"])]
    fig, ax = plt.subplots(figsize=(3.45, 2.45))
    ax.scatter(times, errors, s=55, c=[ORANGE, BLUE], edgecolor="white", linewidth=0.7, zorder=3)
    annotation_styles = [
        {"xytext": (6, -7), "ha": "left", "va": "top"},
        {"xytext": (-6, 6), "ha": "right", "va": "bottom"},
    ]
    for label, x, y, style in zip(labels, times, errors, annotation_styles):
        ax.annotate(label, (x, y), textcoords="offset points", **style)
    ax.set_xscale("log")
    ax.set_xlabel("Median runtime per case (s, log scale)")
    ax.set_ylabel(r"Median MAE ($\mu$V)")
    ax.grid(color="#D0D0D0", linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)
    save(fig, "runtime_tradeoff.pdf")


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    metric_portfolio()
    dataset_summary()
    runtime_tradeoff()
    print("generated metric_portfolio.pdf, dataset_summary.pdf, runtime_tradeoff.pdf")
