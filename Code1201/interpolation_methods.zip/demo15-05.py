from scipy.stats import pearsonr
from scipy.interpolate import interp1d
from matplotlib.backends.backend_pdf import PdfPages
# interpolation module seems to be a custom one, ensure it's in your PYTHONPATH
from interpolation import spherical_spline_interpolation, gsp_BGSRP_recon
# construction module seems to be a custom one, ensure it's in your PYTHONPATH
from construction import vkNNG, adjacency_matrix, adaptive_edge_weighting, NNK, kaliofolias
from scipy.interpolate import NearestNDInterpolator, RBFInterpolator
# pygsp2 might need to be installed if not already
from pygsp2 import graphs, learning
from scipy.spatial.distance import squareform, pdist
import pandas as pd
import mne
import seaborn as sns
import os
import datetime
from mne.channels import compute_native_head_t, read_custom_montage
import matplotlib.pyplot as plt
import numpy as np
import joypy
from itertools import product
from collections import defaultdict
from dtaidistance import dtw  # dtaidistance might need to be installed
plt.close('all')

# =============================================================================
# Placeholder for custom modules if they are not found
# You should have these files (interpolation.py, construction.py) in your working directory
# or installed in your Python environment.
# =============================================================================
try:
    from interpolation import spherical_spline_interpolation, gsp_BGSRP_recon
except ImportError:
    print("Warning: Custom module 'interpolation' not found. Spherical Spline and BGSRP will fail.")
    # Define dummy functions if not found, so the script can run further for other methods

    def spherical_spline_interpolation(X, measures, s):
        print("spherical_spline_interpolation called but not found (dummy).")
        # Return something plausible: NaNs for the missing values
        nan_indices = np.isnan(measures)
        result = np.zeros_like(measures)
        result[nan_indices] = np.nan
        return result

    def gsp_BGSRP_recon(graph, missing_idx, y0, param_BGSRP):
        print("gsp_BGSRP_recon called but not found (dummy).")
        # Return something plausible: y0 repeated or NaNs
        # BGSRP expects a list containing the array
        return [np.full_like(y0, np.nan)]

try:
    from construction import vkNNG, adjacency_matrix, adaptive_edge_weighting, NNK, kaliofolias
except ImportError:
    print("Warning: Custom module 'construction' not found. Graph construction methods will fail.")
    # Define dummy functions for graph construction if not found

    def dummy_adjacency_matrix(X, k_or_radius, sigma, method):
        N = X.shape[0]
        print(f"dummy_adjacency_matrix for {method} called (dummy).")
        # Adjacency matrix and optional second return
        return np.zeros((N, N)), None

    def vkNNG(Z_scaled, k_min, k_max, beta_factor):
        N = Z_scaled.shape[0]
        print("vkNNG called (dummy).")
        return np.zeros((N, N)), None

    def adaptive_edge_weighting(X, W_knn, sigma):
        N = X.shape[0]
        print("adaptive_edge_weighting called (dummy).")
        return np.zeros((N, N))

    def NNK(X, k):
        N = X.shape[0]
        print("NNK called (dummy).")
        return np.zeros((N, N)), np.zeros((N, N))

    def kaliofolias(Z_scaled, a, b, gamma):
        N = Z_scaled.shape[0]
        print("kaliofolias called (dummy).")
        return np.zeros((N, N))

    # Replace original calls if module not found
    adjacency_matrix = dummy_adjacency_matrix
# =============================================================================

# Setup for reading the raw data
data_path = mne.datasets.sample.data_path()
subjects_dir = data_path / "subjects"
fname_raw = data_path / "MEG" / "sample" / "sample_audvis_raw.fif"
bem_dir = subjects_dir / "sample" / "bem"
fname_bem = bem_dir / "sample-5120-5120-5120-bem-sol.fif"
fname_src = bem_dir / "sample-oct-6-src.fif"

misc_path = mne.datasets.misc.data_path()
fname_T1_electrodes = misc_path / "sample_eeg_mri" / "T1_electrodes.mgz"
fname_mon = misc_path / "sample_eeg_mri" / "sample_mri_montage.elc"

dig_montage = read_custom_montage(
    fname_mon,
    head_size=None,
    coord_frame="mri",
    verbose="error",  # because it contains a duplicate point
)
# Preload for easier manipulation
raw = mne.io.read_raw_fif(fname_raw, preload=True)
raw.pick(picks=["eeg", "stim"])  # .load_data() is not needed if preload=True
raw.set_montage(dig_montage)

raw.set_eeg_reference(projection=True)
events = mne.find_events(raw)
epochs = mne.Epochs(raw, events)
# cov = mne.compute_covariance(epochs, tmax=0.0) # Cov not used in the provided snippet for interpolation
evoked = epochs["1"].average()  # trigger 1 in auditory/left
df = evoked.to_data_frame()
times = df.to_numpy()[:, 0]
signals = df.to_numpy()[:, 1:]  # EEG data (times x channels)
sensor_pos_dict = dig_montage.get_positions()['ch_pos']
# Ensure sensor_pos aligns with channels in 'signals'
ch_names_from_evoked = evoked.ch_names  # These are the channels in 'signals'
X = np.array([sensor_pos_dict[ch]
             for ch in ch_names_from_evoked if ch in sensor_pos_dict])
# Filter signals to match X if some channels were not in sensor_pos_dict (e.g. STIM)
original_signal_ch_names = df.columns[1:]
valid_ch_indices = [i for i, name in enumerate(
    original_signal_ch_names) if name in sensor_pos_dict]
signals = signals[:, valid_ch_indices]


N, d = X.shape  # N is number of channels, d is spatial dimensions (3)
print(f"Number of channels (N): {N}, Signal shape: {signals.shape}")


# %%
# Escala si es necesario (Scaling for graph construction, not strictly for all interpolators)
X_scaled = X - np.kron(np.ones((N, 1)), np.mean(X, axis=0))
bounding_radius = 0.5 * \
    np.linalg.norm(np.amax(X_scaled, axis=0) - np.amin(X_scaled, axis=0), 2)
scale = np.power(N, 1. / float(min(d, 3))) / 10.
X_scaled *= scale / bounding_radius
Z = squareform(pdist(X))
Z_scaled = squareform(pdist(X_scaled))

# %%Hiperparametros for graph construction
sigma = np.mean(Z_scaled)/3
radius = np.mean(Z_scaled)
k = 5
# vknn
k_min = 2
k_max = 10
beta_factor = 0.01
# Kaliofolias
a = 0.34
b = 0.4
gamma_kal = 0.04  # Renamed to avoid conflict with BGSRP gamma

# interpolation hyperparameters
param_grid = {
    "Tikhonov": {
        "tau_tik": [0.01, 0.1, 1]  # tau=0 can be problematic
    },
    "BGSRP": {
        "bandw": [N // 10, N // 4],
        "gamma_bgsrp": [0.01, 1]  # Renamed to avoid conflict
    },
    "RBFI MQ": {
        "epsilon_MQ": [0.9, 1.0, 1.1]
    },
    "Spline Superficie": {
        "s_SSI": [10.0, 50.0, 100.0]
    }
}
# %% Construccion de Grafos (Do this once)
print("Constructing graphs...")
try:
    # Use X_scaled for graph if desired
    W_knn, _ = adjacency_matrix(X_scaled, k, sigma=sigma, method="knn")
    W_knn = W_knn.toarray()
    G_knn = graphs.Graph(W_knn)
    G_knn.compute_fourier_basis()

    W_enn, _ = adjacency_matrix(
        X_scaled, radius=radius, sigma=sigma, method="radius_neighbors")
    W_enn = W_enn.toarray()
    G_enn = graphs.Graph(W_enn)
    G_enn.compute_fourier_basis()

    W_vknn, k_values = vkNNG(Z_scaled, k_min, k_max, beta_factor)
    W_vknn = W_vknn.toarray()
    G_vknn = graphs.Graph(W_vknn)
    G_vknn.compute_fourier_basis()

    # AEW typically uses a base W_knn
    W_aew = adaptive_edge_weighting(X_scaled, W_knn, sigma)
    G_aew = graphs.Graph(W_aew)
    G_aew.compute_fourier_basis()

    W_nnk, W_knn_nnk = NNK(X_scaled, k)
    W_nnk = W_nnk.toarray()
    W_knn_nnk = W_knn_nnk.toarray()
    G_nnk = graphs.Graph(W_nnk)
    G_nnk.compute_fourier_basis()

    W_kaliofolias = kaliofolias(Z_scaled, a, b, gamma_kal)
    G_kaliofolias = graphs.Graph(W_kaliofolias)
    G_kaliofolias.compute_fourier_basis()

    weights_dict = {
        f"KNN(k={k},σ={sigma:.2f})": W_knn,
        f"Radius(r={radius:.2f},σ={sigma:.2f})": W_enn,
        f"VKNN(k_min={k_min},k_max={k_max},β={beta_factor})": W_vknn,
        f"Kaliofolias(a={a},b={b},γ={gamma_kal:.2f})": W_kaliofolias,
        f"NNK(k={k})": W_nnk,
        f"AEW(k={k},σ={sigma:.2f})": W_aew,
    }
    graphs_dict = {
        f"KNN(k={k},σ={sigma:.2f})": G_knn,
        f"Radius(r={radius:.2f},σ={sigma:.2f})": G_enn,
        f"VKNN(k_min={k_min},k_max={k_max},β={beta_factor})": G_vknn,
        f"Kaliofolias(a={a},b={b},γ={gamma_kal:.2f})": G_kaliofolias,
        f"NNK(k={k})": G_nnk,
        f"AEW(k={k},σ={sigma:.2f})": G_aew,
    }
    print("Graphs constructed.")
except Exception as e:
    print(f"Error during graph construction: {
          e}. Graph-based methods might fail or use dummy graphs.")
    # Create dummy graphs if construction fails to allow script to run
    dummy_G = graphs.Graph(np.zeros((N, N)))
    dummy_G.compute_fourier_basis()
    graphs_dict = {name: dummy_G for name in [
        f"KNN(k={k},σ={sigma:.2f})", f"Radius(r={radius:.2f},σ={sigma:.2f})",
        f"VKNN(k_min={k_min},k_max={k_max},β={beta_factor})",
        f"Kaliofolias(a={a},b={b},γ={gamma_kal:.2f})", f"NNK(k={k})",
        f"AEW(k={k},σ={sigma:.2f})"
    ]}
    weights_dict = {name: np.zeros((N, N)) for name in graphs_dict.keys()}


# %% Procesamiento iterativo: Iterating over each electrode as missing
# Store MAE for each method, for each "missing electrode" scenario.
# The list will contain MAEs, each MAE being an average over timepoints for that scenario.
all_scenarios_mae_results = defaultdict(list)
all_scenarios_dtw_results = defaultdict(list)
T = signals.shape[0]  # Number of timepoints

for missing_electrode_idx in range(N):
    print(f"Processing scenario: Electrode {
          missing_electrode_idx+1}/{N} is missing...")

    # Define mask for the current missing electrode
    mask = np.ones(N, dtype=bool)
    mask[missing_electrode_idx] = False

    # Store MAE for each method (averaged over time) for THIS missing electrode scenario
    mae_for_current_scenario_avg_over_time = defaultdict(
        list)  # Temp dict to collect errors over time
    interpolated_series_for_dtw_current_scenario = defaultdict(list)
   # Para almacenar los errores MAE en cada instante t para este escenario
    mae_values_at_each_t_current_scenario = defaultdict(list)

    for t in range(T):  # Iterate over time points
        signal_at_t = signals[t, :]
        # This is our 'y'
        true_value_at_missing_electrode = signal_at_t[missing_electrode_idx]

        # Create measures with NaN for the missing electrode at current time t
        measures_at_t = signal_at_t.copy()
        measures_at_t[missing_electrode_idx] = np.nan

        # Known values for interpolation
        known_values = measures_at_t[mask]
        known_positions = X[mask, :]
        # Ensure it's 2D for interpolators
        missing_position = X[[missing_electrode_idx], :]

        # --- Interpolation Methods ---

        # Métodos sin grafo
        for method_name, params in param_grid.items():
            if method_name == "RBFI MQ":
                for epsilon in params["epsilon_MQ"]:
                    label = f"RBFI MQ(ε={epsilon})"
                    try:
                        interpolator = RBFInterpolator(
                            known_positions, known_values, kernel='multiquadric', epsilon=epsilon)
                        y_hat_arr = interpolator(missing_position)
                        y_hat = y_hat_arr[0]
                        error = np.abs(y_hat - true_value_at_missing_electrode)
                        mae_for_current_scenario_avg_over_time[label].append(
                            error)
                        interpolated_series_for_dtw_current_scenario[label].append(
                            y_hat)
                    except Exception as e:
                        # print(f"Error in {label} at t={t}, missing_idx={missing_electrode_idx}: {e}")
                        mae_for_current_scenario_avg_over_time[label].append(
                            np.nan)

            elif method_name == "Spline Superficie":
                # s_param_initial es el s inicial que le pasaremos
                for s_param_initial in params["s_SSI"]:
                    # Etiqueta con el s inicial
                    label = f"Spline Superficie(s={s_param_initial})"
                    try:
                        # La función ahora maneja internamente los reintentos con s mayores
                        interpolated_signal_full = spherical_spline_interpolation(
                            X, measures_at_t, s_initial=s_param_initial
                        )
                        y_hat = interpolated_signal_full[missing_electrode_idx]

                        if np.isnan(y_hat):  # Si la interpolación falló y devolvió NaN
                            error = np.nan
                        else:
                            error = np.abs(
                                y_hat - true_value_at_missing_electrode)
                        mae_for_current_scenario_avg_over_time[label].append(
                            error)
                        interpolated_series_for_dtw_current_scenario[label].append(
                            y_hat)
                    except Exception as e:
                        # print(f"Error en {label} en la llamada principal, t={t}, missing_idx={missing_electrode_idx}: {e}")
                        mae_for_current_scenario_avg_over_time[label].append(
                            np.nan)

        # Interpoladores básicos (sin parámetros)
        try:
            label_nni = "NNI"
            interpolator_nni = NearestNDInterpolator(
                known_positions, known_values)
            y_hat_nni_arr = interpolator_nni(missing_position)
            y_hat_nni = y_hat_nni_arr[0]
            error_nni = np.abs(y_hat_nni - true_value_at_missing_electrode)
            mae_for_current_scenario_avg_over_time[label_nni].append(error_nni)
            interpolated_series_for_dtw_current_scenario[label].append(
                y_hat)
        except Exception as e:
            # print(f"Error in NNI at t={t}, missing_idx={missing_electrode_idx}: {e}")
            mae_for_current_scenario_avg_over_time[label_nni].append(np.nan)

        try:
            label_rbfi_tps = "RBFI TPS"
            # Default RBFInterpolator is Thin Plate Spline if kernel not specified
            interpolator_rbf_tps = RBFInterpolator(
                known_positions, known_values)
            y_hat_rbf_tps_arr = interpolator_rbf_tps(missing_position)
            y_hat_rbf_tps = y_hat_rbf_tps_arr[0]
            error_rbf_tps = np.abs(
                y_hat_rbf_tps - true_value_at_missing_electrode)
            mae_for_current_scenario_avg_over_time[label_rbfi_tps].append(
                error_rbf_tps)
            interpolated_series_for_dtw_current_scenario[label].append(
                y_hat)
        except Exception as e:
            # print(f"Error in RBFI TPS at t={t}, missing_idx={missing_electrode_idx}: {e}")
            mae_for_current_scenario_avg_over_time[label_rbfi_tps].append(
                np.nan)

        # Métodos con grafo
        for graph_name_key, graph_obj in graphs_dict.items():
            # Ensure graph has fourier basis
            if not hasattr(graph_obj, 'U') or graph_obj.U is None:
                try:
                    graph_obj.compute_fourier_basis()
                    if not hasattr(graph_obj, 'U') or graph_obj.U is None:  # still no U
                        raise ValueError("Fourier basis computation failed.")
                except Exception as e_fourier:
                    # print(f"Skipping graph {graph_name_key} for t={t}, missing_idx={missing_electrode_idx} due to Fourier basis error: {e_fourier}")
                    continue

            if "Tikhonov" in param_grid:
                for tau in param_grid["Tikhonov"]["tau_tik"]:
                    label = f"Tikhonov({graph_name_key},τ={tau})"
                    try:
                        y_tikh_full = learning.regression_tikhonov(
                            graph_obj, measures_at_t, mask, tau)
                        y_hat_tikh = y_tikh_full[missing_electrode_idx]
                        error_tikh = np.abs(
                            y_hat_tikh - true_value_at_missing_electrode)
                        mae_for_current_scenario_avg_over_time[label].append(
                            error_tikh)
                        interpolated_series_for_dtw_current_scenario[label].append(
                            y_hat)
                    except Exception as e:
                        # print(f"Error in {label} at t={t}, missing_idx={missing_electrode_idx}: {e}")
                        mae_for_current_scenario_avg_over_time[label].append(
                            np.nan)

            # Check U again
            if "BGSRP" in param_grid and hasattr(graph_obj, 'U') and graph_obj.U is not None:
                try:
                    fx = graph_obj.U.T @ signal_at_t  # Project original full signal
                    for bandw, gamma_val in product(param_grid["BGSRP"]["bandw"], param_grid["BGSRP"]["gamma_bgsrp"]):
                        label = f"BGSRP({graph_name_key},bandw={
                            bandw},γ={gamma_val})"
                        try:
                            # Check if bandw is too large
                            if graph_obj.U.shape[1] < bandw:
                                # print(f"Skipping {label} for t={t}, missing_idx={missing_electrode_idx}: bandw ({bandw}) > num_eigenvectors ({graph_obj.U.shape[1]})")
                                mae_for_current_scenario_avg_over_time[label].append(
                                    np.nan)
                                continue

                            # Low-pass filter version
                            f_hat = graph_obj.U[:, :bandw] @ fx[:bandw]
                            # Initial guess for missing value
                            y0_bgsrp = f_hat[[missing_electrode_idx]]

                            # Ensure your gsp_BGSRP_recon uses this gamma
                            param_BGSRP = {
                                "bandw": bandw, "gamma": gamma_val, 'basis': 'lp-ture'}
                            # gsp_BGSRP_recon expects missing_idx as an array/list of indices
                            y_BGSRP_arr = gsp_BGSRP_recon(
                                graph_obj, [missing_electrode_idx], y0_bgsrp, param_BGSRP)
                            # It returns a list containing an array
                            y_hat_BGSRP = y_BGSRP_arr[0][0]
                            error_BGSRP = np.abs(
                                y_hat_BGSRP - true_value_at_missing_electrode)
                            mae_for_current_scenario_avg_over_time[label].append(
                                error_BGSRP)
                            interpolated_series_for_dtw_current_scenario[label].append(
                                y_hat)
                        except Exception as e_bgsrp_inner:
                            # print(f"Error in {label} (inner) at t={t}, missing_idx={missing_electrode_idx}: {e_bgsrp_inner}")
                            mae_for_current_scenario_avg_over_time[label].append(
                                np.nan)
                except Exception as e_bgsrp_outer:
                    # print(f"Error in BGSRP (outer setup) for {graph_name_key} at t={t}, missing_idx={missing_electrode_idx}: {e_bgsrp_outer}")
                    # Assign NaN to all BGSRP combinations for this graph if outer setup fails
                    for bandw, gamma_val in product(param_grid["BGSRP"]["bandw"], param_grid["BGSRP"]["gamma_bgsrp"]):
                        label = f"BGSRP({graph_name_key},bandw={
                            bandw},γ={gamma_val})"
                        mae_for_current_scenario_avg_over_time[label].append(
                            np.nan)

    # After iterating through all time points 't' for the current 'missing_electrode_idx':
    # Calculate the average MAE over time for each method for this specific missing electrode scenario
    for label, errors_over_time in mae_for_current_scenario_avg_over_time.items():
        if errors_over_time:  # Ensure list is not empty
            avg_mae_this_scenario = np.nanmean(errors_over_time)
            all_scenarios_mae_results[label].append(avg_mae_this_scenario)
        else:  # Should not happen if initialized correctly, but as a safeguard
            all_scenarios_mae_results[label].append(np.nan)
     # 2. Calcular y guardar DTW para este escenario
    original_signal_series = signals[:, missing_electrode_idx]
    # Asegurar que la señal original es del tipo correcto y finita
    s1_original = np.ascontiguousarray(original_signal_series, dtype=np.double)
    if not np.all(np.isfinite(s1_original)):
        print(f"Advertencia DTW: Señal original para electrodo {
              missing_electrode_idx} contiene no-finitos. DTW podría fallar para este electrodo.")
        # Si s1 no es finita, todos los DTW para este electrodo serán NaN.

    for label, interpolated_points in interpolated_series_for_dtw_current_scenario.items():
        dtw_distance_to_store = np.nan  # Valor por defecto
        # Solo si la serie interpolada está completa y la original es finita
        if len(interpolated_points) == T and np.all(np.isfinite(s1_original)):
            interpolated_s = np.array(interpolated_points)

            # DTW requiere que ambas series no tengan NaNs y sean finitas
            if np.any(np.isnan(interpolated_s)) or not np.all(np.isfinite(interpolated_s)):
                # print(f"Advertencia DTW: Serie interpolada para '{label}' (electrodo {missing_electrode_idx}) contiene NaNs o no-finitos. Saltando DTW.")
                pass  # dtw_distance_to_store ya es np.nan
            else:
                try:
                    s2_interpolated = np.ascontiguousarray(
                        interpolated_s, dtype=np.double)

                    # Usar la normalización que tenías antes: distancia / longitud del camino
                    # dtw.warping_paths es más costoso. Considera dtw.distance_fast si la velocidad es crítica y puedes normalizar de otra forma.
                    distance_val, paths_val = dtw.warping_paths(
                        # psi=0 -> sin ventana Sakoe-Chiba
                        s1_original, s2_interpolated, use_c=False, psi=0)

                    if distance_val == np.inf or not paths_val.any():
                        # print(f"Advertencia DTW: Distancia infinita o path inválido para '{label}' (electrodo {missing_electrode_idx}).")
                        pass
                    else:
                        best_path_val = dtw.best_path(paths_val)
                        if len(best_path_val) > 0:
                            dtw_distance_to_store = distance_val / \
                                len(best_path_val)
                        else:
                            # print(f"Advertencia DTW: Longitud de mejor path es cero para '{label}' (electrodo {missing_electrode_idx}).")
                            pass
                except Exception as e_dtw:
                    # print(f"Error calculando DTW para '{label}' (electrodo {missing_electrode_idx}): {e_dtw}")
                    pass  # dtw_distance_to_store ya es np.nan
        else:
            if not np.all(np.isfinite(s1_original)):
                # Mensaje ya impreso arriba
                pass
            # else:
                # print(f"Advertencia DTW: Serie interpolada para '{label}' (electrodo {missing_electrode_idx}) incompleta ({len(interpolated_points)}/{T}). Saltando DTW.")
                pass

        all_scenarios_dtw_results[label].append(dtw_distance_to_store)


# %% Post-processing: all_scenarios_mae_results now contains lists of MAEs for each method
# Each list has N elements, where N is the number of electrodes (scenarios)

# Calculate median MAE for sorting boxplot (optional, but makes plot easier to read)
median_maes_for_sorting = {
    # Ensure maes is not empty
    label: np.nanmedian(maes) for label, maes in all_scenarios_mae_results.items() if maes
}
# Filter out methods that might have all NaNs if errors occurred consistently
valid_labels_for_plot = [
    label for label, median_val in median_maes_for_sorting.items() if not np.isnan(median_val)]

if not valid_labels_for_plot:
    print("No valid data to plot for boxplot. All methods might have resulted in NaN errors.")
else:
    sorted_labels_for_boxplot = sorted(
        valid_labels_for_plot, key=lambda label: median_maes_for_sorting[label])

    # Prepare data for boxplot in the sorted order
    boxplot_data = [all_scenarios_mae_results[label]
                    for label in sorted_labels_for_boxplot]

    # Filter out completely empty or all-NaN series from boxplot_data and their labels
    filtered_boxplot_data = []
    filtered_labels_for_boxplot = []
    for i in range(len(boxplot_data)):
        # Keep if there's at least one non-NaN value
        if np.sum(~np.isnan(boxplot_data[i])) > 0:
            filtered_boxplot_data.append(boxplot_data[i])
            filtered_labels_for_boxplot.append(sorted_labels_for_boxplot[i])
# Crear un DataFrame con los resultados para facilitar el ranking y algunas gráficas
mae_data_list_for_df = []
# Usar las etiquetas ya filtradas y ordenadas (por mediana)
for label in filtered_labels_for_boxplot:
    maes_for_label = all_scenarios_mae_results[label]
    for mae_value in maes_for_label:
        if not np.isnan(mae_value):  # Solo añadir valores no NaN
            mae_data_list_for_df.append({'Method': label, 'MAE': mae_value})

if not mae_data_list_for_df:
    print("No hay datos MAE válidos para crear el DataFrame y las gráficas detalladas.")
    # Salir o manejar este caso para que no fallen las siguientes secciones
    df_mae_results_long = pd.DataFrame()  # DataFrame vacío
else:
    df_mae_results_long = pd.DataFrame(mae_data_list_for_df)

    # Asegurar que el orden de los métodos en el DataFrame sea el mismo que el ordenado por mediana MAE
    # Esto es importante para que los gráficos de seaborn/joypy sigan el ranking.
    df_mae_results_long['Method'] = pd.Categorical(
        df_mae_results_long['Method'], categories=filtered_labels_for_boxplot, ordered=True)
    if not df_mae_results_long.empty:
        df_mae_results_long = df_mae_results_long.sort_values('Method')


# %%  Ranking de Métodos
print("\n--- Ranking de Métodos de Interpolación (ordenados por Mediana MAE ascendente) ---")
if not df_mae_results_long.empty:
    # Calcular estadísticas agregadas para el ranking
    ranking_stats = df_mae_results_long.groupby('Method', observed=True)['MAE'].agg(
        ['median', 'mean', 'std', 'min', 'max', lambda x: np.percentile(
            x.dropna(), 25), lambda x: np.percentile(x.dropna(), 75)]
    ).rename(columns={'<lambda_0>': '25th_percentile', '<lambda_1>': '75th_percentile'})
    print(ranking_stats)

    # Guardar ranking en CSV (opcional)
    timestamp_csv = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    csv_ranking_path = f"ranking_interpolacion_EEG_{timestamp_csv}.csv"
    try:
        # ranking_stats.to_csv(csv_ranking_path)
        print(f"\nRanking guardado en: {csv_ranking_path}")
    except Exception as e:
        print(f"\nNo se pudo guardar el ranking en CSV: {e}")
else:
    print("No hay datos para generar el ranking.")


# %%  Visualización
pdf_figs = []  # Lista para almacenar las figuras que se guardarán en el PDF

# === Figura 1: Matrices de pesos (si todavía la generas y quieres incluirla) ===
if 'weights_dict' in locals() and weights_dict:  # Verificar si weights_dict existe y no está vacío
    try:
        fig1 = plt.figure(figsize=(12, 8))
        plot_idx = 1
        num_weights = len(weights_dict)
        cols = 3
        rows = (num_weights + cols - 1) // cols
        for title_w, W_matrix in weights_dict.items():
            if plot_idx > rows * cols:
                break
            plt.subplot(rows, cols, plot_idx)
            plt.imshow(W_matrix, aspect='auto', cmap='viridis')  # Añadido cmap
            plt.title(title_w.split('(')[0], fontsize=9)
            plot_idx += 1
        plt.suptitle("Graph Adjacency Matrices", fontsize=16)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        pdf_figs.append(fig1)
    except Exception as e:
        print(f"Error al crear fig1 (matrices de pesos): {e}")
        if 'fig1' in locals() and fig1:
            plt.close(fig1)  # Cerrar si se creó parcialmente


# === Figura de Boxplot para MAE (Modificada) ===
if not df_mae_results_long.empty:
    try:
        # Determinar dinámicamente el espacio necesario para las etiquetas a la izquierda
        # Esto es un poco heurístico. Podrías necesitar ajustarlo.
        # Longitud máxima de etiqueta * un factor pequeño + un offset.
        max_label_len = 0
        if filtered_labels_for_boxplot:  # Asegurarse que la lista no está vacía
            max_label_len = max(len(s) for s in filtered_labels_for_boxplot)

        # Ejemplo: 0.1 base + 0.007 por carácter, max 40%
        left_margin = min(0.1 + max_label_len * 0.007, 0.4)

        fig_boxplot, ax_boxplot = plt.subplots(
            # Más ancho
            figsize=(14, max(8, len(filtered_labels_for_boxplot) * 0.4)))

        sns.boxplot(y='Method', x='MAE', data=df_mae_results_long, ax=ax_boxplot, orient='h',
                    order=filtered_labels_for_boxplot, palette='viridis', showfliers=True)  # Usando seaborn

        ax_boxplot.set_xscale('log')
        ax_boxplot.set_xlabel("Log Mean Absolute Error (MAE)", fontsize=12)
        ax_boxplot.set_ylabel("Interpolation Method", fontsize=12)
        ax_boxplot.set_title(
            f"Distribution of MAE (N={N} scenarios) - Boxplot", fontsize=14)
        ax_boxplot.grid(True, axis='x', linestyle='--', alpha=0.7)
        ax_boxplot.grid(True, axis='y', linestyle=':', alpha=0.4)

        # Ajustar el margen izquierdo
        # Aumentar espacio a la izquierda para etiquetas
        fig_boxplot.subplots_adjust(left=left_margin)
        # plt.tight_layout() # Puede entrar en conflicto con subplots_adjust, usar con cuidado o después

        pdf_figs.append(fig_boxplot)
    except Exception as e:
        print(f"Error al crear fig_boxplot: {e}")
        if 'fig_boxplot' in locals() and fig_boxplot:
            plt.close(fig_boxplot)

# === Figura de Violinplot para MAE ===
if not df_mae_results_long.empty:
    try:
        max_label_len = 0
        if filtered_labels_for_boxplot:
            max_label_len = max(len(s) for s in filtered_labels_for_boxplot)
        left_margin_violin = min(0.1 + max_label_len * 0.007, 0.4)

        fig_violin, ax_violin = plt.subplots(
            figsize=(14, max(8, len(filtered_labels_for_boxplot) * 0.45)))
        sns.violinplot(y='Method', x='MAE', data=df_mae_results_long, ax=ax_violin, orient='h',
                       order=filtered_labels_for_boxplot, hue='Method', palette='plasma', inner='quartile', cut=0, legend=False)
        # inner: None, 'box', 'quartile', 'point', 'stick'
        # cut=0 : para que no se extienda más allá de los datos extremos

        ax_violin.set_xscale('log')
        ax_violin.set_xlabel("Log Mean Absolute Error (MAE)", fontsize=12)
        ax_violin.set_ylabel("Interpolation Method", fontsize=12)
        ax_violin.set_title(
            f"Distribution of MAE (N={N} scenarios) - Violin Plot", fontsize=14)
        ax_violin.grid(True, axis='x', linestyle='--', alpha=0.7)
        ax_violin.grid(True, axis='y', linestyle=':', alpha=0.4)
        fig_violin.subplots_adjust(left=left_margin_violin)
        pdf_figs.append(fig_violin)
    except Exception as e:
        print(f"Error al crear fig_violin: {e}")
        if 'fig_violin' in locals() and fig_violin:
            plt.close(fig_violin)
fig_ridge = None  # Inicializar fig_ridge a None
# === Figura de Ridgeline Plot para MAE (usando joypy si está disponible) ===
if not df_mae_results_long.empty:
    try:
        methods_with_any_positive_mae = df_mae_results_long[df_mae_results_long['MAE'] > 0]['Method'].unique(
        )

        if len(methods_with_any_positive_mae) == 0:
            print("Advertencia para Ridgeline Plot: Ningún método tiene valores MAE > 0. No se generará el gráfico log-escalado.")
        else:
            df_for_joyplot = df_mae_results_long[df_mae_results_long['Method'].isin(
                methods_with_any_positive_mae)].copy()
            ordered_methods_for_joyplot = [
                m for m in filtered_labels_for_boxplot if m in methods_with_any_positive_mae]

            if not ordered_methods_for_joyplot:
                print(
                    "Advertencia para Ridgeline Plot: No quedan métodos para mostrar después de filtrar por MAE > 0.")
            else:
                df_for_joyplot['Method'] = pd.Categorical(
                    df_for_joyplot['Method'], categories=ordered_methods_for_joyplot, ordered=True)
                df_for_joyplot = df_for_joyplot.sort_values('Method')

                if df_for_joyplot.empty:
                    print(
                        "Advertencia para Ridgeline Plot: DataFrame para joyplot vacío después del filtrado. No se generará el gráfico.")
                else:
                    # ordered_methods_for_joyplot tiene los nombres de los métodos que esperamos plotear (ej. 26)
                    # joypy puede crear un número diferente de ejes (ej. 27)

                    fig_ridge, axes_ridge = joypy.joyplot(
                        df_for_joyplot,
                        by='Method',
                        column='MAE',
                        # La altura se basa en el número de categorías que *intentamos* plotear
                        figsize=(
                            12, max(8, len(ordered_methods_for_joyplot) * 0.40)),
                        alpha=0.85,
                        linewidth=0.5,
                        linecolor='black',
                        colormap=plt.colormaps['autumn_r'],
                        overlap=1.5,
                    )

                    is_list_of_axes = isinstance(
                        axes_ridge, (list, np.ndarray))
                    num_axes_created = len(axes_ridge) if is_list_of_axes else (
                        1 if axes_ridge is not None else 0)
                    num_expected_methods = len(ordered_methods_for_joyplot)

                    print(f"DEBUG Joyplot: Ejes creados por joypy: {
                          num_axes_created}")
                    print(f"DEBUG Joyplot: Métodos esperados (ordered_methods_for_joyplot): {
                          num_expected_methods}")

                    # Iterar sobre TODOS los ejes que joypy creó
                    if is_list_of_axes and num_axes_created > 0:
                        for ax_r_idx, ax_r in enumerate(axes_ridge):
                            current_method_name_for_axis = "Eje Extra/Desconocido"
                            # Series vacía por defecto
                            ax_data_series = pd.Series(dtype=float)

                            if ax_r_idx < num_expected_methods:
                                # Este eje corresponde a uno de nuestros métodos esperados
                                current_method_name_for_axis = ordered_methods_for_joyplot[ax_r_idx]
                                ax_data_series = df_for_joyplot[df_for_joyplot['Method']
                                                                == current_method_name_for_axis]['MAE']
                            else:
                                # Este es un eje más allá de nuestra lista de métodos (el eje 27 en tu caso)
                                print(f"Info: Procesando eje extra de Joyplot (índice {
                                      ax_r_idx}). Se usará escala lineal.")

                            # Determinar escala para este eje
                            can_log_scale_this_axis = False
                            if not ax_data_series.empty and not ax_data_series[ax_data_series > 0].empty:
                                can_log_scale_this_axis = True

                            final_xlabel_for_ridge = ""
                            if can_log_scale_this_axis:
                                try:
                                    ax_r.set_xscale('log')
                                    min_positive_val = ax_data_series[ax_data_series > 0].min(
                                    )

                                    current_ax_xlim_right = ax_r.get_xlim()[1]
                                    new_left_lim = min_positive_val * 0.1
                                    if new_left_lim <= 0:
                                        new_left_lim = 1e-9
                                    ax_r.set_xlim(
                                        left=new_left_lim, right=current_ax_xlim_right)
                                    final_xlabel_for_ridge = "Log Mean Absolute Error (MAE)"
                                except ValueError as ve_log:
                                    print(f"Advertencia: No se pudo aplicar escala log al eje para '{
                                          current_method_name_for_axis}' (idx {ax_r_idx}): {ve_log}. Usando escala lineal.")
                                    ax_r.set_xscale('linear')
                                    final_xlabel_for_ridge = f"MAE para '{
                                        current_method_name_for_axis}' (Lineal)"
                            else:
                                ax_r.set_xscale('linear')
                                if ax_data_series.empty and current_method_name_for_axis == "Eje Extra/Desconocido":
                                    final_xlabel_for_ridge = "MAE (Eje extra, lineal)"
                                else:
                                    final_xlabel_for_ridge = f"MAE para '{
                                        current_method_name_for_axis}' (Lineal/Sin datos >0)"

                            # Configurar xlabel solo para el último eje general
                            if ax_r_idx == num_axes_created - 1:
                                ax_r.set_xlabel(
                                    final_xlabel_for_ridge if final_xlabel_for_ridge else "Mean Absolute Error", fontsize=10)
                            else:
                                ax_r.set_xlabel("")
                                ax_r.set_xticklabels([])

                    # Caso de un solo eje (poco probable aquí)
                    elif not is_list_of_axes and axes_ridge is not None:
                        # ... (lógica simplificada similar para un solo eje) ...
                        if not df_for_joyplot['MAE'][df_for_joyplot['MAE'] > 0].empty:
                            try:
                                axes_ridge.set_xscale('log')
                                # ... (set xlim) ...
                                axes_ridge.set_xlabel(
                                    "Log Mean Absolute Error (MAE)", fontsize=12)
                            except ValueError:
                                axes_ridge.set_xscale('linear')
                                axes_ridge.set_xlabel(
                                    "MAE (Lineal)", fontsize=12)
                        else:
                            axes_ridge.set_xscale('linear')
                            axes_ridge.set_xlabel(
                                "MAE (Sin datos >0)", fontsize=12)

                    else:  # No se crearon ejes o axes_ridge no es una lista/array
                        print(
                            "Advertencia: Joyplot no devolvió una estructura de ejes esperada.")

                    # Título general de la figura
                    # Basar el ajuste del título en el número de métodos que SÍ esperábamos
                    title_y_pos = 1.0 + \
                        (len(ordered_methods_for_joyplot) * 0.015)
                    if fig_ridge:  # Asegurarse que fig_ridge es una figura válida
                        fig_ridge.suptitle(
                            f"Distribution of MAE - Ridgeline Plot", fontsize=14, y=title_y_pos)
                        pdf_figs.append(fig_ridge)

    except Exception as e:
        # Aquí se capturó el "list index out of range"
        print(f"Error general al crear fig_ridge (joypy): {e}")
        if 'fig_ridge' in locals() and fig_ridge is not None and isinstance(fig_ridge, plt.Figure):
            plt.close(fig_ridge)
        elif 'axes_ridge' in locals() and axes_ridge is not None:
            try:  # axes_ridge podría ser un array de matplotlib.axes.Axes
                if isinstance(axes_ridge, (list, np.ndarray)) and len(axes_ridge) > 0:
                    # Cerrar la figura del primer eje
                    plt.close(axes_ridge[0].figure)
                elif hasattr(axes_ridge, 'figure'):  # Si es un solo eje
                    plt.close(axes_ridge.figure)
            except Exception as e_close:
                print(
                    f"Error al intentar cerrar figura de joyplot fallida: {e_close}")
        fig_ridge = None
# --- Procesamiento de Resultados DTW ---
dtw_data_list_for_df = []
# Usaremos las etiquetas que resultaron válidas para el MAE o crearemos unas nuevas para DTW
# Para este ejemplo, ordenaremos por mediana DTW.
# Primero, recolectar todas las medianas DTW válidas
median_dtws_for_sorting = {}
for label, dtw_list in all_scenarios_dtw_results.items():
    valid_dtws = [d for d in dtw_list if pd.notna(d)]
    if valid_dtws:
        median_dtws_for_sorting[label] = np.nanmedian(valid_dtws)

# Filtrar métodos que solo tuvieron NaNs o listas vacías para DTW
valid_labels_for_dtw_plot = list(median_dtws_for_sorting.keys())

if not valid_labels_for_dtw_plot:
    print("No hay datos DTW válidos para generar el boxplot y ranking DTW.")
    # Crear DataFrame vacío para evitar errores posteriores
    df_dtw_results_long = pd.DataFrame()
else:
    # Ordenar las etiquetas por la mediana de DTW
    sorted_labels_for_dtw_boxplot = sorted(
        valid_labels_for_dtw_plot, key=lambda label: median_dtws_for_sorting[label])

    for label in sorted_labels_for_dtw_boxplot:
        dtw_values_for_label = all_scenarios_dtw_results[label]
        for dtw_value in dtw_values_for_label:
            if pd.notna(dtw_value):  # Solo añadir valores no NaN
                dtw_data_list_for_df.append(
                    {'Method': label, 'DTW_Normalized': dtw_value})

    if not dtw_data_list_for_df:
        print("Advertencia: Lista de datos DTW para DataFrame está vacía después del filtrado de NaNs.")
        df_dtw_results_long = pd.DataFrame()
    else:
        df_dtw_results_long = pd.DataFrame(dtw_data_list_for_df)
        # Asegurar el orden categórico para el gráfico
        df_dtw_results_long['Method'] = pd.Categorical(
            df_dtw_results_long['Method'], categories=sorted_labels_for_dtw_boxplot, ordered=True)
        df_dtw_results_long = df_dtw_results_long.sort_values('Method')

# --- Tabla de Ranking DTW ---
print("\n--- Ranking de Métodos por DTW Normalizado (Mediana ascendente) ---")
if not df_dtw_results_long.empty:
    dtw_ranking_stats = df_dtw_results_long.groupby('Method', observed=True)['DTW_Normalized'].agg(
        ['median', 'mean', 'std', 'min', 'max',
         lambda x: np.percentile(x.dropna(), 25),
         lambda x: np.percentile(x.dropna(), 75)]
    ).rename(columns={'<lambda_0>': '25th_pctl_DTW', '<lambda_1>': '75th_pctl_DTW'})

    dtw_ranking_stats = dtw_ranking_stats.sort_values(
        by='median', ascending=True)
    print(dtw_ranking_stats)

    # Guardar ranking DTW en CSV (opcional)
    timestamp_csv = datetime.datetime.now().strftime(
        "%Y-%m-%d_%H-%M-%S")  # O usa uno existente si lo tienes
    csv_dtw_ranking_path = f"ranking_dtw_interpolacion_EEG_{timestamp_csv}.csv"
    try:
        dtw_ranking_stats.to_csv(csv_dtw_ranking_path)
        print(f"\nRanking DTW guardado en: {csv_dtw_ranking_path}")
    except Exception as e:
        print(f"\nNo se pudo guardar el ranking DTW en CSV: {e}")
else:
    print("No hay datos DTW para generar la tabla de ranking.")

# --- Boxplot para DTW ---
fig_dtw_boxplot = None
if not df_dtw_results_long.empty:
    try:
        max_label_len_dtw = max(len(
            s) for s in sorted_labels_for_dtw_boxplot) if sorted_labels_for_dtw_boxplot else 0
        # Ajustar estos valores si es necesario
        left_margin_dtw = min(0.1 + max_label_len_dtw * 0.0075, 0.45)

        fig_dtw_boxplot, ax_dtw_boxplot = plt.subplots(
            figsize=(14, max(8, len(sorted_labels_for_dtw_boxplot) * 0.4)))

        sns.boxplot(y='Method', x='DTW_Normalized', data=df_dtw_results_long, ax=ax_dtw_boxplot, orient='h',
                    order=sorted_labels_for_dtw_boxplot,
                    hue='Method', palette='crest',  # Paleta diferente para DTW
                    hue_order=sorted_labels_for_dtw_boxplot,
                    showfliers=True, legend=False)

        # Determinar si usar escala logarítmica para DTW
        # Las distancias DTW normalizadas suelen ser más pequeñas y con menos rango que MAE, pero verificar.
        use_log_scale_dtw = False
        if not df_dtw_results_long['DTW_Normalized'][df_dtw_results_long['DTW_Normalized'] > 0].empty:
            min_dtw_val = df_dtw_results_long['DTW_Normalized'][df_dtw_results_long['DTW_Normalized'] > 0].min(
            )
            max_dtw_val = df_dtw_results_long['DTW_Normalized'].max()
            if pd.notna(min_dtw_val) and pd.notna(max_dtw_val) and min_dtw_val > 0 and (max_dtw_val / min_dtw_val) > 50:  # Umbral heurístico
                use_log_scale_dtw = True

        if use_log_scale_dtw:
            ax_dtw_boxplot.set_xscale('log')
            ax_dtw_boxplot.set_xlabel(
                "Log(Distancia DTW Normalizada)", fontsize=12)
            # Asegurar que el límite izquierdo es positivo si se usa escala log
            min_positive_dtw = df_dtw_results_long['DTW_Normalized'][df_dtw_results_long['DTW_Normalized'] > 0].min(
            )
            if pd.notna(min_positive_dtw) and min_positive_dtw > 0:
                ax_dtw_boxplot.set_xlim(left=min_positive_dtw * 0.5)
            # Fallback si todos los valores son cero o Nan y aun así se intenta log (no debería pasar)
            else:
                # Un valor muy pequeño positivo
                ax_dtw_boxplot.set_xlim(left=1e-9)
        else:
            ax_dtw_boxplot.set_xlabel("Distancia DTW Normalizada", fontsize=12)

        ax_dtw_boxplot.set_ylabel("Método de Interpolación", fontsize=12)
        ax_dtw_boxplot.set_title(
            f"Distribución de Distancia DTW Normalizada (N={N} escenarios)", fontsize=14)
        ax_dtw_boxplot.grid(True, axis='x', linestyle='--', alpha=0.7)
        ax_dtw_boxplot.grid(True, axis='y', linestyle=':', alpha=0.4)
        # Ajustar margen para etiquetas largas
        fig_dtw_boxplot.subplots_adjust(left=left_margin_dtw)

        pdf_figs.append(fig_dtw_boxplot)
    except Exception as e:
        print(f"Error al crear fig_dtw_boxplot: {e}")
        if fig_dtw_boxplot:
            plt.close(fig_dtw_boxplot)  # Cerrar si se creó parcialmente
        fig_dtw_boxplot = None  # Asegurar que es None si falló

# === Guardar todo en PDF ===
if pdf_figs:  # Solo si hay figuras para guardar
    timestamp_pdf = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    pdf_path = f"reporte_interpolaciones_EEG_{timestamp_pdf}.pdf"
    print(f"\nIntentando guardar PDF en: {pdf_path}")

    with PdfPages(pdf_path) as pdf:
        for i, fig_to_save in enumerate(pdf_figs):
            if fig_to_save and isinstance(fig_to_save, plt.Figure):
                try:
                    # Para el boxplot y violinplot, donde ajustamos el margen izquierdo:
                    if fig_to_save == locals().get('fig_boxplot') or fig_to_save == locals().get('fig_violin'):
                        # Usar el ajuste de subplots_adjust
                        pdf.savefig(fig_to_save)
                    else:
                        # Para otras figuras como fig1 o joyplot
                        pdf.savefig(fig_to_save, bbox_inches='tight')
                    print(f"Figura {i+1} guardada en el PDF.")
                except Exception as e:
                    print(f"Error al guardar figura {i+1} en el PDF: {e}")
                finally:
                    # Cerrar la figura para liberar memoria
                    plt.close(fig_to_save)
            else:
                print(
                    f"Figura {i+1} no es un objeto Figure válido o es None, no se guardará.")
    print(f"PDF '{pdf_path}' creado/actualizado.")

    if os.name == "nt":
        try:
            os.startfile(pdf_path)
        except Exception as e:
            print(f"No se pudo abrir el PDF automáticamente: {e}")
else:
    print("\nNo se generaron figuras para guardar en el PDF.")

# The DTW results_df is also omitted as it was tied to graficar_grupo
# results_df = results_df.sort_values(by='Value', ascending=True).reset_index(drop=True)
# print(results_df)

# Your "Falta" list:
# - Time-Varying Graphs: Not implemented here, would require graph re-computation or dynamic updates.
# - SS MNE: MNE has its own bad channel interpolation (e.g., `raw.interpolate_bads()`) which uses spherical splines. You could add it as another method.
# - Iterar sobre cantidad de electrodos faltantes: This script now iterates with 1 missing. For more, you'd need another outer loop for `num_missing` and a way to choose combinations of missing electrodes.
# - Cambiar dataset: Easily done by changing the data loading part.
# - Verificar cada metodo con su dataset: Refers to testing methods on datasets where they are known to perform well, or on synthetic data.
# - Optimizar hyperparametros: This script uses fixed grids. Optimization (e.g., GridSearchCV-like approach) is a separate, larger task, possibly per graph or per method.
# - pyunlockbox: If this is a specific toolbox, its integration would be custom.
# - Añadir Time-it: You can use `time.time()` around sections or `timeit` module for more precise measurements.
